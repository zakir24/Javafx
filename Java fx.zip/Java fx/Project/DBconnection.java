
package home;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBconnection {
 public Connection getConnection() throws SQLException{
    //database 
       String dburl="jdbc:mysql://localhost:3306/Tour";
       String username="root";
       String pass="";
       Connection con =null;
       
       try{
           con=DriverManager.getConnection(dburl, username, pass);
           System.out.println("successfull");
       }
       catch(SQLException e)
       {
           System.out.println("not done");
       } 
      
    return con;

       }       
  }
