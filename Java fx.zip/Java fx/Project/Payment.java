
package home;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Paint;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;







public class Payment extends Application{
     public void start(Stage primaryStage) {
        Text t=new Text("Package ID");
          Text te=new Text("User Name");
           Text tex=new Text("Contact");
            Label textttt=new Label("Details about Payment");
             Text text=new Text("Card Number");
          Text textt=new Text("Cvv Code");
           Text texttt=new Text("Expiration Date MM/YYYY");

               TextField tf=new TextField();
                TextField tf1=new TextField();
                TextField tf2=new TextField();
                TextField tf3=new TextField();
                  TextField tf4=new TextField();
                    TextField tf5=new TextField();
                    
     
                Button bt=new Button("Confirm");
               bt.setOnAction(value->{
                
                
      Connection con = null;
PreparedStatement pst = null;
try{
String query = "INSERT INTO Package(PackageID,UserName,Contact,CardNumber,CvvCode,ExpirationDate) VALUES (?, ?, ?, ?, ?,?)";
con = DriverManager.getConnection("jdbc:mysql://localhost/Tour", "root", "");
pst=con.prepareStatement(query);
pst.setString(1, tf.getText());
pst.setString(2, tf1.getText());
pst.setString(3, tf2.getText());
pst.setString(4, tf3.getText());
//pst.setString(5, tex.getSelectedItem().toString());
pst.setString(5, tf4.getText());
pst.setString(6, tf5.getText());

pst.executeUpdate();
JOptionPane.showMessageDialog(null, "Successfull your order.We will contact within 24 hours");
 
 
}catch(Exception ex){
JOptionPane.showMessageDialog(null, ex);
 
}
               });
                              Button b=new Button("Back");
                           b.setOnAction(value->{
                    
                 Stage s = new Stage();
                 Package sc=new Package();
         
                  sc.start(s);
                      primaryStage.close();
           });
               GridPane gp=new GridPane();
      
                  gp.add(t,1,1);
                  gp.add(te,1,2);  
                  gp.add(tex,1,3);
                      gp.add(textttt,1,4);
                  gp.add(text,1,5);  
                  gp.add(textt,1,6);
                   gp.add(texttt,1,7);
                   
                            gp.add(tf,2,1);
                  gp.add(tf1,2,2);  
                  gp.add(tf2,2,3);
                  
                  gp.add(tf3,2,5);  
                  gp.add(tf4,2,6);
                   gp.add(tf5,2,7);
                   gp.add(bt,1,8);
                   gp.add(b,0,8);
            
                   gp.setVgap(5); 
                  gp.setHgap(5);    
                                gp.setAlignment(Pos.CENTER);
              gp.setMinSize(1000, 500); 
                textttt.setTextFill(Paint.valueOf("white"));
               gp.setStyle("-fx-background-color: brown;");
                   gp.setPadding(new Insets(10, 10, 10, 10)); 
                        Scene scene = new Scene(gp);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }



         
         
     
    
}

    

