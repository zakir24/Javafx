
package home;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Paint;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Package extends Application{
      public void start(Stage primaryStage) {
          Button bt=new Button("Click here to order");
      
                 bt.setOnAction(value->{
                    
                 Stage s = new Stage();
                 Payment sc=new  Payment();
         
                  sc.start(s);
                      primaryStage.close();
           });
          
          
          
          
          
            Button btnn=new Button("Next page");
      
             Button b=new Button("Back");
               b.setOnAction(value->{
                    
                 Stage s = new Stage();
                 log sc=new log();
         
                  sc.start(s);
                      primaryStage.close();
           });
              
            Label label = new Label("Package ID:1030 (Kashmir)  3 Days 2 Nights  rs.7500 Approximate");
label.setMaxWidth(100);
label.setWrapText(true);
        Label labe = new Label("Package ID:1033 (Goa)  3 Days 2 Nights  rs.7500 Approximate");
labe.setMaxWidth(100);
labe.setWrapText(true);
     Label lab = new Label("Package ID:1037  ( Santorini, Greece)  3 Days 2 Nights  rs.7500 Approximate");
lab.setMaxWidth(100);
lab.setWrapText(true);
               Label la = new Label("Package ID:1038  (Cappadocia, Turkey)  3 Days 2 Nights  rs.7500 Approximate");
la.setMaxWidth(100);
la.setWrapText(true);
              Label l = new Label("Package ID:1040  (Venice, Italy)  3 Days 2 Nights  rs.7500 Approximate");
l.setMaxWidth(100);
l.setWrapText(true);

            Label sohel = new Label("Package ID:1049 (Blue Lagoon, Iceland)  3 Days 2 Nights  rs.7500 Approximate");
sohel.setMaxWidth(100);
sohel.setWrapText(true);
        Label sohe = new Label("Package ID:1050 ( Tianzi Mountains, China)  3 Days 2 Nights  rs.7500 Approximate");
sohe.setMaxWidth(100);
sohe.setWrapText(true);
     Label soh = new Label("Package ID:1043 ( Geiranger Fjord, Norway)  3 Days 2 Nights  rs.7500 Approximate");
soh.setMaxWidth(100);
soh.setWrapText(true);
               Label so = new Label("Package ID:1070  (Yosemite Valley, USA )  3 Days 2 Nights  rs.7500 Approximate");
so.setMaxWidth(100);
so.setWrapText(true);
              Label s = new Label("Package ID:1067  (Rio De Janeiro, Brazil)  3 Days 2 Nights  rs.7500 Approximate");
s.setMaxWidth(100);
s.setWrapText(true);
          
          Image img = new Image("file:///D:/SD/1k.jpg");
        ImageView imgView = new ImageView(img);
        
        
        
        
     
        Image im = new Image("file:///D:/SD/2g.jpg");
        ImageView imView = new ImageView(im);
        
        Image i = new Image("file:///D:/SD/3s.jpg");
        ImageView iView = new ImageView(i);
        
               Image ic = new Image("file:///D:/SD/t4.jpg");
        ImageView imVie = new ImageView(ic);
        
        Image it = new Image("file:///D:/SD/v5.jpg");
        ImageView iVe = new ImageView(it);
        
        
        Image zakir = new Image("file:///D:/SD/b6.jpg");
        ImageView prant = new ImageView(zakir);
        
        Image zaki = new Image("file:///D:/SD/c7.jpg");
        ImageView pran = new ImageView(zaki);
        
               Image zak = new Image("file:///D:/SD/n8.jpg");
        ImageView pra = new ImageView(zak);
        
        Image za = new Image("file:///D:/SD/u9.jpg");
        ImageView pr = new ImageView(za);
                       Image z = new Image("file:///D:/SD/b10.jpg");
        ImageView p = new ImageView(z);
     
        
        
        imgView.setFitWidth(100);
      imgView.setFitHeight(100);
       imView.setFitWidth(100);
      imView.setFitHeight(100);
       iView.setFitWidth(100);
      iView.setFitHeight(100);
       imVie.setFitWidth(100);
      imVie.setFitHeight(100);
       iVe.setFitWidth(100);
      iVe.setFitHeight(100);
      
          prant.setFitWidth(100);
      prant.setFitHeight(100);
       pran.setFitWidth(100);
      pran.setFitHeight(100);
       pra.setFitWidth(100);
      pra.setFitHeight(100);
       pr.setFitWidth(100);
      pr.setFitHeight(100);
       p.setFitWidth(100);
      p.setFitHeight(100);
           GridPane gp=new GridPane();
             gp.add(imgView,1,1);
             gp.add(imView,2,1);
               gp.add(iView,3,1);
                    gp.add(imVie,4,1);
                          gp.add(iVe,5,1);
                     gp.add(prant,1,3);
                       gp.add(pran,2,3);
                         gp.add(pra,3,3);
                           gp.add(pr,4,3);
                             gp.add(p,5,3);
          
                gp.add(label,1,2);
                   gp.add(labe,2,2);
                      gp.add(lab,3,2);
                           gp.add(la,4,2);
                             gp.add(l,5,2);
                             
                              gp.add(sohel,1,4);
                   gp.add(sohe,2,4);
                      gp.add(soh,3,4);
                           gp.add(so,4,4);
                             gp.add(s,5,4);
                             gp.add(b,2,7);
                             gp.add(bt,3,7);
                              gp.add(btnn,4,7);
          
                   gp.setVgap(20); 
                  gp.setHgap(80); 
                     label.setTextFill(Paint.valueOf("white"));
                        labe.setTextFill(Paint.valueOf("white"));
                           lab.setTextFill(Paint.valueOf("white"));
                              la.setTextFill(Paint.valueOf("white"));
                                 l.setTextFill(Paint.valueOf("white"));
                                  sohel.setTextFill(Paint.valueOf("white"));
                        sohe.setTextFill(Paint.valueOf("white"));
                           soh.setTextFill(Paint.valueOf("white"));
                              so.setTextFill(Paint.valueOf("white"));
                                 s.setTextFill(Paint.valueOf("white"));
                    gp.setStyle("-fx-background-color: brown;");
                 gp.setMinSize(1000, 600); 
                Scene scene = new Scene(gp);
        
        primaryStage.setTitle("Available Package");
        primaryStage.setScene(scene);
        primaryStage.show();
    
      }
    
}
