
package home;

import java.awt.Insets;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;

public class Home extends Application {
    
 
    public void start(Stage primaryStage) {
         Label label = new Label("Your long text here  how aRE YOU YOU ARE BUSY ok no problem: 200 taka g ");
label.setMaxWidth(580);
label.setWrapText(true);

        
        Button bt=new Button("Login");
        bt.setOnAction(value->{
                    //Stage s=new Stage();
                 Stage newWindow = new Stage();
                 log scene=new log();
               
                  scene.start(newWindow);
                      primaryStage.close();
                  
                //newWindow.setScene();
               
 
                //newWindow.show();
            
       
        
    });
        
          Button btn=new Button("Signup");
           btn.setOnAction(value->{
                    
                 Stage s = new Stage();
                 Signup sc=new Signup();
         
                  sc.start(s);
                      primaryStage.close();
           });
                  
          GridPane gp=new GridPane();
          
        Image im = new Image("file:///D:/SD/t.jpg");
        ImageView imView = new ImageView(im);
            gp.setStyle("-fx-background-color: brown;");
             label.setTextFill(Paint.valueOf("white"));
          gp.add(imView,0,0);
        imView.setFitWidth(1000);
      imView.setFitHeight(200);
       gp.setMinSize(1000, 500); 
                //  gp.setAlignment(Pos.CENTER); 
                    gp.add(bt,0,2);
                    gp.add(btn,0,3);
                   gp.add(label,0,1);
        gp.setVgap(5); 
                  gp.setHgap(5);  
        
        Scene scene = new Scene(gp);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
