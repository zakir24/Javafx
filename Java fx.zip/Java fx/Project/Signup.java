
package home;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;





public class Signup extends Application{
     public void start(Stage primaryStage) {
         Text t=new Text("Full Name");
          Text texte=new Text("User Name");
           Text te=new Text("Email");
              Text tex=new Text("Address");
               Text text=new Text("Nationality");
                Text textee=new Text("Password");
                PasswordField p=new PasswordField();
               TextField tf=new TextField();
                TextField tf1=new TextField();
                TextField tf2=new TextField();
                TextField tf3=new TextField();
                  TextField tf4=new TextField();
                
      Text dobLabel = new Text("Date of birth"); 
      

      DatePicker datePicker = new DatePicker(); 
                  Text genderLabel = new Text("Gender"); 
          
      ToggleGroup groupGender = new ToggleGroup(); 
      RadioButton maleRadio = new RadioButton("Male"); 
      maleRadio.setToggleGroup(groupGender); 
      RadioButton femaleRadio = new RadioButton("Female"); 
      femaleRadio.setToggleGroup(groupGender);
                Button bt=new Button("Register");
                bt.setOnAction(value->{
                  //   String query="insert into Signup(FullName,UserName,Email,Address,Nationality,Password)values(?,?,?,?,?,?)";
                     
 
      Connection con = null;
PreparedStatement pst = null;
try{
String query = "INSERT INTO Signup(FullName, Email,Date,UserName,Password,Address, Nationality) VALUES (?, ?, ?, ?, ?, ?,?)";
con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Tour", "root", "");
pst=con.prepareStatement(query);
pst.setString(1, tf.getText());
pst.setString(2, tf1.getText());
pst.setString(3,((TextField)datePicker.getEditor()).getText());
pst.setString(4, tf4.getText());
pst.setString(5, p.getText());
//pst.setString(5, tex.getSelectedItem().toString());
pst.setString(6, tf2.getText());
pst.setString(7, tf3.getText());

pst.executeUpdate();
JOptionPane.showMessageDialog(null, "REGISTER SUCCESSFULLY");
 
 
}catch(Exception ex){
JOptionPane.showMessageDialog(null, ex);
 
}

             
               });
                
                    Button b=new Button("Back");
                 
                           b.setOnAction(value->{
                    
                 Stage s = new Stage();
                 Home sc=new Home();
         
                  sc.start(s);
                      primaryStage.close();
                           });
               GridPane gp=new GridPane();
               gp.add(dobLabel, 0, 2);       
      gp.add(datePicker, 1, 2); 
      
      gp.add(genderLabel, 0,5 ); 
      gp.add(maleRadio, 1, 5);       
      gp.add(femaleRadio, 2, 5);
               gp.add(t,0,0);
                  gp.add(te,0,1);
                  gp.add(texte,0,3);
                     gp.add(tf4,1,3);
                     gp.add(textee,0,4);
                     gp.add(p,1,4);
                     gp.add(tex,0,6);
                        gp.add(text,0,7);
                           gp.add(tf,1,0);
                            gp.add(tf1,1,1);
                             gp.add(tf2,1,6);
                              gp.add(tf3,1,7);
                                 gp.add(bt,1,8);
                                   gp.add(b,0,8);
                   gp.setVgap(5); 
                  gp.setHgap(5);    
                                gp.setAlignment(Pos.CENTER);
              gp.setMinSize(1000, 500); 
               gp.setStyle("-fx-background-color: brown;");
                   gp.setPadding(new Insets(10, 10, 10, 10)); 
                        Scene scene = new Scene(gp);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }



         
         
     
    
}
