
package home;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class log extends Application{
 public void start(Stage primaryStage) {
       Text tx=new Text("User Name");
        Text txt=new Text("Password");
        TextField tf=new TextField();
         PasswordField tf1=new  PasswordField ();
         Button btn=new Button("Login");
         
         
   
           btn.setOnAction(value->{
                    
                 Stage s = new Stage();
                 Package sc=new  Package();
         
                  sc.start(s);
                      primaryStage.close();
           });
             Button bt=new Button("Back");
                 bt.setOnAction(value->{
                    
                 Stage s = new Stage();
                 Home sc=new  Home();
         
                  sc.start(s);
                      primaryStage.close();
           });
                              
         GridPane gp=new GridPane();

             gp.setAlignment(Pos.CENTER);
              gp.setMinSize(1000, 500); 
                   gp.setPadding(new Insets(10, 10, 10, 10));
                    gp.setStyle("-fx-background-color: brown;");
              gp.add(tx,0,0);
         gp.add(txt,0,1);
        gp.add(tf,1,0);
          gp.add(tf1,1,1);
            gp.add(btn,1,2);
             gp.add(bt,0,2);
               gp.setVgap(5); 
                  gp.setHgap(5);  
        Scene scene = new Scene(gp);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    


  
    
}
}
