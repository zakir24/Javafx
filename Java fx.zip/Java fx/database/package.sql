-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2019 at 08:13 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tour`
--

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `PackageID` int(10) NOT NULL,
  `UserName` varchar(10) NOT NULL,
  `Contact` varchar(30) NOT NULL,
  `CardNumber` int(20) NOT NULL,
  `CvvCode` int(15) NOT NULL,
  `ExpirationDate` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`PackageID`, `UserName`, `Contact`, `CardNumber`, `CvvCode`, `ExpirationDate`) VALUES
(145233, 'fgywe', 'sndgfa', 3274, 2364, '02/2020'),
(213, 'gmail', 'zaki', 761345, 2416, '03/2021'),
(213, 'gmail', 'zaki', 761345, 2416, '03/2021'),
(1030, 'zakir22', 'zakir.pranto@gmail.com', 234578, 45678, '02/2020'),
(1043, 'zakir', '097355346', 46575645, 747575, '12/2021'),
(1043, 'zakir', '01700000000', 12768, 567, '12/2020');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
